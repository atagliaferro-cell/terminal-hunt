import time

def slow_print(text):
    for char in text:
        print(char, end="", flush=True)
        time.sleep(0.02)
    print()

slow_print("Initializing...")
time.sleep(1)

slow_print("\nYou made it.\n")
time.sleep(1)

slow_print("This is where most fail.")
time.sleep(1)

slow_print("\nYour next answer is not found here.\n")

slow_print("Five letters decide your fate each day,")
slow_print("colours will guide you on your way.")
slow_print("Green is truth, and yellow near,")
slow_print("return with the word once it is clear.\n")

answer = input("Enter the word: ").lower()

if answer != "envy":
    slow_print("\nThat’s not what the colours said.")
    exit()

slow_print("\n...Correct.\n")
time.sleep(1)

code = input("Enter the name you uncovered earlier: ").lower()

if code != "freida":
    slow_print("\nYou’ve forgotten already.")
    exit()

slow_print("\nImpressive.")
slow_print("You’re still in the game.\n")

slow_print("More is coming...")
